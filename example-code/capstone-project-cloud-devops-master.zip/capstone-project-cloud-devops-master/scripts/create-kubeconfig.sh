aws eks \
--region us-west-2 \
update-kubeconfig \
--name $1 \